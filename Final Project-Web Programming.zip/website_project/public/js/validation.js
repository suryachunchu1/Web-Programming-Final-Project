const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
        const username = e.target.username.value.trim();
        const email = e.target.email.value.trim();
        const password = e.target.password.value.trim();

        if (username.length < 3) {
            alert('Username must be at least 3 characters long.');
            e.preventDefault();
            return;
        }

        if (!validateEmail(email)) {
            alert('Please enter a valid email address.');
            e.preventDefault();
            return;
        }

        if (password.length < 6) {
            alert('Password must be at least 6 characters long.');
            e.preventDefault();
            return;
        }
    });
}

const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
        const email = e.target.email.value.trim();
        const password = e.target.password.value.trim();

        if (!validateEmail(email)) {
            alert('Please enter a valid email address.');
            e.preventDefault();
            return;
        }

        if (password.length === 0) {
            alert('Password cannot be empty.');
            e.preventDefault();
            return;
        }
    });
}

const createForm = document.getElementById('createForm');
if (createForm) {
    createForm.addEventListener('submit', (e) => {
        const title = e.target.title.value.trim();
        const description = e.target.description.value.trim();

        if (title.length === 0) {
            alert('Title cannot be empty.');
            e.preventDefault();
            return;
        }

        if (description.length === 0) {
            alert('Description cannot be empty.');
            e.preventDefault();
            return;
        }
    });
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
