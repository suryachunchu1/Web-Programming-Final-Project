const express = require('express');
const db = require('../db');

const router = express.Router();

// Middleware to check if user is logged in
const isAuthenticated = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/auth/login');
    }
};

// Dashboard
router.get('/dashboard', isAuthenticated, (req, res) => {
    res.render('dashboard', { user: req.session.user });
});

// Create Data
router.get('/create', isAuthenticated, (req, res) => {
    res.render('create', { user: req.session.user });
});

router.post('/create', isAuthenticated, (req, res) => {
    const { title, artist, album, genre, year, average_rating, description } = req.body;
    const query = `
        INSERT INTO data (title, artist, album, genre, year, average_rating, description, created_by) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;
    db.query(query, [title, artist, album, genre, year, average_rating, description, req.session.user.id], (err) => {
        if (err) {
            console.error(err);
            res.status(500).send("Error while creating record");
            return;
        }
        res.redirect('/crud/read');
    });
});

// Read Data
router.get('/read', isAuthenticated, (req, res) => {
    const query = `SELECT id, title, artist, album, genre, year, average_rating, description FROM data WHERE created_by = ?`;
    db.query(query, [req.session.user.id], (err, results) => {
        if (err) throw err;
        res.render('read', { user: req.session.user, data: results });
    });
});

// Update Data
router.get('/update/:id', isAuthenticated, (req, res) => {
    const query = `SELECT * FROM data WHERE id = ? AND created_by = ?`;
    db.query(query, [req.params.id, req.session.user.id], (err, results) => {
        if (err || results.length === 0) res.redirect('/crud/read');
        res.render('update', { user: req.session.user, entry: results[0] });
    });
});

router.post('/update/:id', isAuthenticated, (req, res) => {
    const { title, artist, album, genre, year, average_rating, description } = req.body;
    const query = `UPDATE data SET title = ?, artist = ?, album = ?, genre = ?, year = ?, average_rating = ?, description = ? WHERE id = ? AND created_by = ?`;
    db.query(query, [title, artist, album, genre, year, average_rating, description, req.params.id, req.session.user.id], (err) => {
        if (err) throw err;
        res.redirect('/crud/read');
    });
});

// Delete Data
router.get('/delete/:id', isAuthenticated, (req, res) => {
    const query = `DELETE FROM data WHERE id = ? AND created_by = ?`;
    db.query(query, [req.params.id, req.session.user.id], (err) => {
        if (err) throw err;
        res.redirect('/crud/read');
    });
});

module.exports = router;
